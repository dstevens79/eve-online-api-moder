// Quick test to check if Settings component can be imported
try {
  console.log('Testing Settings component import...');
  // This would normally be a TypeScript test, but we'll simulate



