// Quick test to verify the database connection functionality works


const config = {
  host: 'localhost',
  port: 3306,
  autoReconnect: fal
};
const manager = new Datab
// Test the m
manager.testConnection()
    console.log('✅ 
  .catch(error => {
  });










  .catch(error => {
    console.error('❌ Test failed:', error);
  });